package dvm.service.controller.admin;

public interface AdminServiceController {

    // 클래스 다이어그램이랑 인자이름이 다르긴함...
    void process(int itemId, int num);
}
