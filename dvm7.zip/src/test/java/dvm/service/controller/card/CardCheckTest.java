package dvm.service.controller.card;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CardCheckTest {
    private CardCheck cardCheck;

//    @BeforeEach
//    public void setUp() {
//        cardCheck = new CardCheck();
//    }
//
//    @Test
//    public void testCheckCard_insufficientBalance_abcd() {
//        assertFalse(cardCheck.checkCard("abcd", 5000));
//    }
//
//    @Test
//    public void testCheckCard_success_efgh() {
//        assertTrue(cardCheck.checkCard("efgh", 1000));
//    }
//
//    @Test
//    public void testCheckCard_insufficientBalance_efgh() {
//        assertFalse(cardCheck.checkCard("efgh", 3000));
//    }
//
//    @Test
//    public void testCheckCard_success_ijkl() {
//        assertTrue(cardCheck.checkCard("ijkl", 1000));
//    }



}